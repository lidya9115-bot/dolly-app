# DOLLY starter project

A free, multilingual (English, Arabic, French) responsive web-app/PWA prototype.

## Files
- `index.html`: the app interface and starter features
- `manifest.json`: installable app metadata
- `sw.js`: basic offline cache
- `icon.svg`: app icon

## Try it on your computer
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. The first version stores diary entries, goals, routines and reminders locally in that browser/device.

Note: local browser storage is not cloud sync, account backup, or secure private storage. Do not store sensitive secrets in this prototype.

## Publish free with GitHub Pages
1. Create a GitHub account at https://github.com/
2. Create a new public repository named `dolly-app`.
3. Upload all four project files (not the ZIP itself) to the repository root.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
6. Wait for the published URL shown in the Pages section.

GitHub Pages publishes static websites. This prototype does not yet include user accounts or cloud database.
